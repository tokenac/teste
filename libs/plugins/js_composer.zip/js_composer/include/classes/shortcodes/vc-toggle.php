<?php
class WPBakeryShortCode_VC_Toggle extends WPBakeryShortCode {
	public function outputTitle( $title ) {
		return '';
	}
}